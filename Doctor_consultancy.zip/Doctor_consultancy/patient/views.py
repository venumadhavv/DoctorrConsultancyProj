import imp
import re
from django.shortcuts import redirect, render

# Create your views here.
from .models import Patient,Doctor

from .forms import PatientForm

def home(request):
    return render(request,'home.html')

# def ViewAllDoctors(request):
#     all_doctors=Doctor.objects.all()
    # return render(request,'patient/')
def ViewAllPatients(request):
    all_users=Patient.objects.all()
    return render(request,'patient/view_all_users.html',{'data':all_users})

def patientregister(request):
    patientform=PatientForm()
    if request.method=='POST':
        name=request.POST.get('username')
        email=request.POST.get('email')
        password=request.POST.get('password')
        mobile=request.POST.get('phoneno')
        age=request.POST.get('age')
        country=request.POST.get('country')
        state=request.POST.get('state')
        city=request.POST.get('city')
        Patient.objects.create(name=name,email=email,password=password,mobile_number=mobile,age=age,country=country,state=state,city=city)

        return redirect('login')
    return render(request,'patient/patient_regiser.html')

def userlogin(request):
    obj=None
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        try:
            obj=Patient.objects.get(email=email,password=password)
            return redirect('view')
        except:
            pass
    return render(request,'patient/patient_login.html')

def editprofie(request,pk):
    id=Patient.objects.get(user_id=pk)
    form=PatientForm(instance=id)
    if request.method=='POST':
        forms=PatientForm(request.POST,instance=id)
        if forms.is_valid():
            forms.save()
            return redirect('view')
    return render(request,'viewuser.html',{'forms':form})


def viewprofile(request,pk):
    id=Patient.objects.get(user_id=pk)
    return render(request,'patient/view_user_profile.html',{'i':id})

