from django.urls import URLPattern, path
from . import views

urlpatterns=[
    path('',views.home,name='home'),
    path('5',views.ViewAllPatients,name='view'),
    path('1/',views.patientregister,name='create'),
    path('2/',views.userlogin,name='login'),
    path('3/<str:pk>/',views.editprofie,name='edit'),
    path('4/<str:pk>/',views.viewprofile,name="viewprofile")
]